<?php $__env->startSection('content'); ?>



    <div id="comparison" class="row">

        <?php $__currentLoopData = $deelnemers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deelnemer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-6">

                <form method="POST" action="/">

                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="hot" value="<?php echo e($deelnemer->id); ?>">
                    <input type="hidden" name="not" value="<?php echo e($deelnemer->oponent_id); ?>">
                    <button type="submit">
                        <img src="<?php echo e('img/candidates/' . $deelnemer->filename); ?>" class="pic"
                             alt="<?php echo e($deelnemer->name); ?>">
                    </button>

                </form>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <div class="row link">
        <div class="col-md-12">

            <a href="<?php echo e(route('leaderboard')); ?>"><h6>LEADERBOARD</h6></a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>