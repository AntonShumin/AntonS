<?php $__env->startSection('content'); ?>

    <div id="leaderboards">

        <div class="col-md-6">

            <?php if( count($deelnemers) == 1 ): ?>
                <a href="<?php echo e(route('leaderboard')); ?>" class="btn btn-info center-block" role="button">Back to the leaderboard</a>
            <?php else: ?>
                <a href="<?php echo e(route('add')); ?>" class="btn btn-info center-block" role="button">Upload a face</a>
            <?php endif; ?>

        </div>

        <table class="table table-responsive">
            <thread>
                <tr>
                    <th></th>
                    <th>Foto</th>
                    <th>Naam</th>
                    <th>Percentage</th>
                    <th>Hots</th>
                    <th>Nots</th>
                </tr>
            </thread>
            <tbody>
            <?php $__currentLoopData = $deelnemers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $deelnemer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><img src="<?php echo e('/img/candidates/' . $deelnemer->filename); ?>" alt=""></td>
                    <td><?php echo e($deelnemer->name); ?></td>
                    <td><?php echo e(round( $deelnemer->sum ) . "%"); ?></td>
                    <td><?php echo e($deelnemer->hot); ?></td>
                    <td><?php echo e($deelnemer->not); ?></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="row link">
            <div class="col-md-12">

                <a href="<?php echo e(route('home')); ?>"><h6>PLAY</h6></a>

            </div>

        </div>

    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>