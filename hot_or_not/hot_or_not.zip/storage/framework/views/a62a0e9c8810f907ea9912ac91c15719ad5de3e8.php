<?php $__env->startSection('content'); ?>

    <div id="upload">

        <form action="/leaderboard/add" method="post" enctype="multipart/form-data">

            <div class="col-md-12">
                <h3>Upload your beautiful picture</h3>
            </div>

            <div class="col-md-6">

                <?php echo e(csrf_field()); ?>

                <input type="text" class="form-control" name="name" placeholder="Name" aria-describedby="basic-addon2" required maxlength="10">
                <input type="file" class="form-control" name="file" id="file" accept="image/jpeg" required>
                <input type="submit" class="form-control" value="Upload" name="submit">

            </div>


        </form>

    </div>


    <div class="row link">
        <div class="col-md-12">

            <a href="<?php echo e(route('leaderboard')); ?>"><h6>LEADERBOARD</h6></a>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>